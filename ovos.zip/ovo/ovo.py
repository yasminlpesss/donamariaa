
valor_base = {'pequeno': 7.80, 'médio': 12.90, 'grande': 23.95}


valores_sabor = {'chocolate preto': 9.67, 'chocolate branco': 4.50, 'chocolate ao leite': 9.32}


valores_adicionais = {'kitkat': 4.67, 'mm\'s': 5.43}


valor_presente = 2.50
valor_entrega = 5.00


tamanho = input("Escolha o tamanho do ovo (pequeno, médio ou grande): ")
sabor = input("Escolha o sabor do recheio (chocolate preto, chocolate branco ou chocolate ao leite): ")
quantidade = int(input("Quantos ovos você deseja comprar? "))


valor_total = valor_base[tamanho] + valores_sabor[sabor]


if input("Deseja adicionar outro recheio? (sim ou não) ") == "sim":
    valor_total += valores_sabor[sabor] / 2


if input("Deseja adicionar KitKat? (sim ou não) ") == "sim":
    valor_total += valores_adicionais['kitkat']
if input("Deseja adicionar MM'S? (sim ou não) ") == "sim":
    valor_total += valores_adicionais['mm\'s']


if input("Deseja que seja presente? (sim ou não) ") == "sim":
    valor_total += valor_presente
if input("Deseja entrega? (sim ou não) ") == "sim":
    valor_total += valor_entrega


valor_total *= quantidade


pagamento = input("Qual é o tipo de pagamento? (dinheiro, pix ou cartão de crédito) ")
if pagamento == "dinheiro" or pagamento == "pix":
    valor_total *= 0.9
elif pagamento == "cartão de crédito":
    valor_total += 3.30


print("O valor total dos ovos de Páscoa escolhidos é: R${:.2f}".format(valor_total))
